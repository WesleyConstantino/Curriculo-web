function redirecionar(){
  window.open("https://www.linkedin.com/in/wesley-constantino-3a5055221/");
}

function redirecionar1(){
  window.open("https://github.com/WesleyConstantino");
}

//funções de mudar a cor dos parágrafos
function trocar(){
   document.getElementById("linkedin").style.color = '#000000';
}

function voltar(){
  document.getElementById("linkedin").style.color = '#00FFFF';
}

//funções de mudar a cor dos parágrafos
function trocar1(){
  document.getElementById("github").style.color = '#000000';
}

function voltar1(){
  document.getElementById("github").style.color = '#00FFFF';
}